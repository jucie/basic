These programs were copied from "BASIC Computer Games" (1973 by David Ahl)
Tarball downloaded from http://www.vintage-basic.net/games.html
